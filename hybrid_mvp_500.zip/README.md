Hybrid MVP - 500 games build

Includes 500+ HTML5 games with generated cover thumbnails in public/thumbnails.

Run frontend: npm install && npm run dev
Run proxy server: cd server && npm install express node-fetch cors && node index.js
